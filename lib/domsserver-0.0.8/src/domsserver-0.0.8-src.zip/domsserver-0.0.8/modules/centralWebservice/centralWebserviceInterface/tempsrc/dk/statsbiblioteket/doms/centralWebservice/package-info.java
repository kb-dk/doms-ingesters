@javax.xml.bind.annotation.XmlSchema(namespace = "http://central.doms.statsbiblioteket.dk/")
package dk.statsbiblioteket.doms.centralWebservice;
