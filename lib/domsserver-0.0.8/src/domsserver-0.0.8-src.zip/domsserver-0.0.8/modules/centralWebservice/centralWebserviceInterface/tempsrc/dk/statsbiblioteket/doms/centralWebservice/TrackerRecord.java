
package dk.statsbiblioteket.doms.centralWebservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TrackerRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TrackerRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="entryContentModelPid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="collectionPid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="date" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="state" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TrackerRecord", propOrder = {
    "pid",
    "entryContentModelPid",
    "collectionPid",
    "date",
    "state"
})
public class TrackerRecord {

    @XmlElement(required = true)
    protected java.lang.String pid;
    @XmlElement(required = true)
    protected java.lang.String entryContentModelPid;
    @XmlElement(required = true)
    protected java.lang.String collectionPid;
    protected long date;
    @XmlElement(required = true)
    protected java.lang.String state;

    /**
     * Gets the value of the pid property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getPid() {
        return pid;
    }

    /**
     * Sets the value of the pid property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setPid(java.lang.String value) {
        this.pid = value;
    }

    /**
     * Gets the value of the entryContentModelPid property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getEntryContentModelPid() {
        return entryContentModelPid;
    }

    /**
     * Sets the value of the entryContentModelPid property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setEntryContentModelPid(java.lang.String value) {
        this.entryContentModelPid = value;
    }

    /**
     * Gets the value of the collectionPid property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getCollectionPid() {
        return collectionPid;
    }

    /**
     * Sets the value of the collectionPid property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setCollectionPid(java.lang.String value) {
        this.collectionPid = value;
    }

    /**
     * Gets the value of the date property.
     * 
     */
    public long getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     */
    public void setDate(long value) {
        this.date = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setState(java.lang.String value) {
        this.state = value;
    }

}
