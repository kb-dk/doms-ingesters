
package dk.statsbiblioteket.doms.centralWebservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for pid_filename_checksum_url_format complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="pid_filename_checksum_url_format">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="filename" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="md5sum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="permanentURL" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="formatURI" type="{http://www.w3.org/2001/XMLSchema}anyURI"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "pid_filename_checksum_url_format", propOrder = {
    "pid",
    "filename",
    "md5Sum",
    "permanentURL",
    "formatURI"
})
public class PidFilenameChecksumUrlFormat {

    @XmlElement(required = true)
    protected java.lang.String pid;
    @XmlElement(required = true)
    protected java.lang.String filename;
    @XmlElement(name = "md5sum", required = true)
    protected java.lang.String md5Sum;
    @XmlElement(required = true)
    protected java.lang.String permanentURL;
    @XmlElement(required = true)
    @XmlSchemaType(name = "anyURI")
    protected java.lang.String formatURI;

    /**
     * Gets the value of the pid property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getPid() {
        return pid;
    }

    /**
     * Sets the value of the pid property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setPid(java.lang.String value) {
        this.pid = value;
    }

    /**
     * Gets the value of the filename property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getFilename() {
        return filename;
    }

    /**
     * Sets the value of the filename property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setFilename(java.lang.String value) {
        this.filename = value;
    }

    /**
     * Gets the value of the md5Sum property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getMd5Sum() {
        return md5Sum;
    }

    /**
     * Sets the value of the md5Sum property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setMd5Sum(java.lang.String value) {
        this.md5Sum = value;
    }

    /**
     * Gets the value of the permanentURL property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getPermanentURL() {
        return permanentURL;
    }

    /**
     * Sets the value of the permanentURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setPermanentURL(java.lang.String value) {
        this.permanentURL = value;
    }

    /**
     * Gets the value of the formatURI property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getFormatURI() {
        return formatURI;
    }

    /**
     * Sets the value of the formatURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setFormatURI(java.lang.String value) {
        this.formatURI = value;
    }

}
